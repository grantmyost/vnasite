<div id="top">
  <img alt="woodworking tools" src="/assets/saw1.jpg">
</div>
<div id="instagram">
	<div class="container">
	  <div class="row">
	  	<div class="span12">
		  <div id="instagram-underline">
		  	<img alt="hammers" src="/assets/hammers-from-logo2.png">
		    <div id="underline-div">
		      <h2 id="instagram-heading">INSTAGRAM</h2>
		      <p>FOLLOW US</p>
		    </div>
		  </div>
		</div>
	  </div>
	  <div class="row instagram-images">

<?php
 
// Make sure SimplePie is included. You may need to change this to match the location of autoloader.php
// For 1.0-1.2:
 
#require_once('../simplepie.inc');
// For 1.3+:
require_once('php/simplepie_1.3.1.compiled.php');
 
// We'll process this feed with all of the default options.
$feed = new SimplePie('http://instagram.com/tags/secondlifestudios/feed/recent.rss');
 
// Set which feed to process.
 
// Run SimplePie.
$feed->init();
 
// This makes sure that the content is sent to the browser as text/html and the UTF-8 character set (since we didn't change it).
$feed->handle_content_type();
 
// Let's begin our HTML webpage code.  The DOCTYPE is supposed to be the very first thing, so we'll keep it on the same line as the closing-PHP tag.
?>

<?php $counter=1; ?>
<?php foreach ($feed->get_items() as $item) { ?>
<?php if ($counter <= 4) { ?>

<div class="span3">
<?php echo $item->get_content(); $counter++; ?>
</div>

<?php } } ?>






<!--
	  	<div class="span3">
	  	  <img alt="instagram" src="/assets/instagram-first.jpg">
	    </div>
	    <div class="span3">
	  	  <img alt="instagram" src="/assets/instagram-second.jpg">
	    </div>
	    <div class="span3">
	  	  <img alt="instagram" src="/assets/instagram-third.jpg">
	    </div>
	    <div class="span3">
	  	  <img alt="instagram" src="/assets/instagram-fourth.jpg">
	    </div>
-->



	  </div>
	</div>
</div>

<div id="who-we-are">
	<div class="container">
	  <div class="row">
	  	<div class="span12">
	  	  <img id="who-we-are-text-heading" alt="who we are" src="/assets/who-we-are-text-heading.png">
	    </div>
	  </div>
	  <div class="row">
	  	<div class="span4">
	  	  <img alt="profile pic" src="/assets/mitch-profile.jpg">
	    </div>
	    <div class="span4">
	  	  <img alt="profile pic" src="/assets/ryan-profile.jpg">
	    </div>
	    <div class="span4">
	  	  <img alt="profile pic" src="/assets/chris-profile.jpg">
	    </div>
	  </div>
	</div>
</div>

<div id="our-story-our-process">
	<div class="container">
	<!--  <div class="row">  -->
        <a href="/?page_id=33"><img id="our-story" alt="our story" src="/assets/wood-585.jpg" /></a>
        <a href="/?page_id=35"><img id="our-process" alt="our process" src="/assets/wood-foot-585.jpg" /></a>

	  	<!--
	  	<div class="span6 omega">
	  	  <a href="#"><img alt="our story" src="/assets/wood-585.jpg" /></a>
	    </div>
	    <div class="span6 alpha">
	  	  <a href="#"><img alt="our process" src="/assets/wood-foot-585.jpg" /></a>
	    </div>
        -->

	<!--  </div>  -->
	</div>
</div>

<div id="contact">
	<div class="container">
	  <div class="row">
	  	<div class="span12">
	  	  <div class="pagination-centered">
	  	  	<h3>CONTACT: CHRIS@SECONDLIFESTUDIOS.COM</h3>
	  	  </div>
	    </div>
	  </div>
	</div>
</div>